# The Pet Shop Website

A simple one-page pet shop website created with HTML and CSS.

## Files
- `index.html` - website structure and content
- `style.css` - website styling and responsive layout
- `images/` - folder reserved for website images

## Project
Happy Paws Pet Shop is a fictional pet store website featuring products, services, and contact information.
